"""fileserver URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.9/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.contrib import admin

from django.conf import settings
from django.conf.urls.static import static
from django.views.generic import RedirectView
from fileserver.views import UploadFile
from fileserver.views import DownloadFile
from fileserver.views import Homepage


#function to handle requests to url
urlpatterns = [
    url(r'^admin/fileserver/filedownload/$', RedirectView.as_view(url='http://172.16.1.16/')),
    url(r'^admin/', admin.site.urls),
    url(r'^upload/$', UploadFile.as_view()),
    url(r'^files/(?P<pk>[0-9]+)/.*$', DownloadFile.as_view()),
    url(r'^$', Homepage.as_view()),
]
